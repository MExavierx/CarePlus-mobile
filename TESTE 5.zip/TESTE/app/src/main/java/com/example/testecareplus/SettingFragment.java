package com.example.testecareplus;

import android.app.Activity;

public class SettingFragment extends Activity {
}
